
from sklearn.compose import make_column_transformer, make_column_selector
from sklearn.preprocessing import OneHotEncoder, StandardScaler
import pandas as pd
import pickle

def  preprocessing(X_train,X_test,scale_nums = True, nombre = 'nombre'):

    cat_selector = make_column_selector(dtype_include='object')
    num_selector = make_column_selector(dtype_include='number')
    
    scaler = StandardScaler()
    ohe = OneHotEncoder(sparse=False,
                        handle_unknown='ignore')
    
    num_tuple = (scaler, num_selector)
    cat_tuple = (ohe, cat_selector)
    
    if scale_nums == True:
    
        col_transformer = make_column_transformer(num_tuple, cat_tuple, remainder = 'passthrough')
        
        col_transformer.fit(X_train)
        
        variables = []
    
        for x in list(col_transformer.get_feature_names_out()):
            x_ = x.replace('standardscaler__','').replace('onehotencoder__','').replace('remainder__','').replace('(','').replace(']','').replace(',','_')
            variables.append(x_)
            
        X_train_processed = col_transformer.transform(X_train)
        X_test_processed = col_transformer.transform(X_test)
        
        X_train_df = pd.DataFrame(X_train_processed, columns = variables, index=X_train.index)
        X_test_df = pd.DataFrame(X_test_processed, columns = variables, index=X_test.index)
        
        pickle.dump(col_transformer, open('col_transformer_{}'.format(nombre), 'wb'))
    
    else:
        col_transformer = make_column_transformer(cat_tuple, remainder = 'passthrough')
        col_transformer.fit(X_train)
        variables = []
        
        for x in list(col_transformer.get_feature_names_out()):
            
            x_ = x.replace('standardscaler__','').replace('onehotencoder__','').replace('remainder__','').replace('(','').replace(']','').replace(',','_')
            variables.append(x_)
    
        X_train_processed = col_transformer.transform(X_train)
        X_test_processed = col_transformer.transform(X_test)
        X_train_df = pd.DataFrame(X_train_processed, columns = variables, index=X_train.index)
        X_test_df = pd.DataFrame(X_test_processed, columns = variables, index=X_test.index)
        pickle.dump(col_transformer, open('col_transformer_{}'.format(nombre), 'wb'))
    
    return X_train_df, X_test_df

